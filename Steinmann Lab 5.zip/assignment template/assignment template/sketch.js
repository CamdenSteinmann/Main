//Variables for ellipse
var x = 20;
  var y = 20;
  var radius = 10;
  
//Variables for rectangle
  var x2 = 150;
  var y2 = 150;
  var w = 75;
  var h = 75;
  
//Variables for key pressed
  var x3 = 50;
  var y3 = 20;
  var radius2 = 10;

function setup() {
  createCanvas(400, 400);
  background(220);
  ellipseMode(RADIUS);
  colorMode(RGB);
}

function draw() {
  ellipse(x,y,radius,radius);
  rect(x2,y2,w,h);
  ellipse(x3,y3,radius2,radius2);
  strokeWeight(15);
  line(1,1,400,1);
  line(1,1,1,400);
  line(1,400,400,400);
  line(400,1,400,400);
  strokeWeight(1);
  text("Start Game",155,190);
  
  
  var d2 = dist(mouseX, mouseY, x3, y3);
  
  if (keyIsPressed === true) {
    if (key == 'w') {
      if (d2 < radius2) {
    fill(70,84,250);
    
  } else{
    fill(255);
  } 
    }
  }
  ellipse(x3,y3,radius2,radius2);
  noFill();
}

function mouseClicked() {
 
  var d = dist(mouseX, mouseY, x, y);
  
  if (d < radius) {
    fill(250,25,21);
    
  } else{
    fill(255);
  } 
   ellipse(x,y,radius,radius);
  noFill();
}
 function mousePressed() {
    if ((mouseX > x2) && (mouseX < x2+w) && (mouseY > y2) && (mouseY < y2+h)) {
      fill(240,164,38);
      
    } else {
      fill(255);
    }
  
   rect(x2,y2,w,h);
   noFill();
   
} 


   