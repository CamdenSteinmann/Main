let vid;

function setup() {
  
noCanvas();

vid = createVideo(
['download.mp4','download.webm','download.ogv'],vidLoad

  );

 vid.size(400,400);
}

function vidLoad() {
  vid.loop();
  vid.showControls();
  vid.volume(0);
  vid.speed(1.0);
  vid.play();

}