var cloudx = 100;
var cloudy = 100;
function setup() {
  createCanvas(400, 400);
  colorMode(RGB);
  angleMode(DEGREES);
}

function draw() {
  background(173, 216, 230);
  triangle(0, 400, 50, 400, 25, 300);
  translate(30,30);
  triangle(0, 400, 50, 400, 25, 300);
  
  triangle(300, 400, 375, 400, 350, 300);
  scale(0.5,1);
  triangle(300, 400, 375, 400, 350, 300);
  translate(20,20);
  triangle(300, 400, 375, 400, 350, 300);
  
  
  

  for(var i = 0; i < 100; i+= 0.5){
    weather(cloudx,cloudy);
    weather(cloudx+100,cloudy+100)
    cloudx += 0.1
   
     }
    print(cloudx)
}

function weather(cloudx,cloudy) {
  push();
  
  //Cloud
  fill(255);
  noStroke();
  ellipse(cloudx,cloudy,70,50);
  ellipse(cloudx + 20,cloudy + 20,70,50);
  ellipse(cloudx - 20,cloudy + 20,70,50);
  
  
  
  pop();
  
}